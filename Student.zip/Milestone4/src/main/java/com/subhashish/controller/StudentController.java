package com.subhashish.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.subhashish.VO.StudentVO;
import com.subhashish.entity.StudentEntity;
import com.subhashish.repository.StudentRepository;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("student")
public class StudentController {
	
	@Autowired
	private StudentRepository repository;
	
	@Autowired
	private Consumer consumer;
	
	@GetMapping("/byid/{id}")
	public Optional<StudentEntity> getMethodName(@PathVariable Integer id) {
		return repository.findById(id);
	}
	
	@GetMapping("/mark/{id}")
	public Optional<StudentVO> getMarks(@PathVariable Integer id) {
		return consumer.getMarks(id);
	}
	
	
	
	@GetMapping("/bylname/{lname}")
	public List<StudentEntity> getMethodName(@PathVariable String lname) {
		return repository.findByLname(lname);
	}
	
	
	@PostMapping("/add")
	public StudentEntity postMethodName(@RequestBody StudentEntity entity) {
		
		return repository.save(entity);
	}
	
	
	
	
	
	

}
