package com.subhashish.controller;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.subhashish.VO.StudentVO;



@FeignClient(url = "http://localhost:8889", value="Student")
public interface Consumer {
	
	@GetMapping("/studentmarks/byid/{id}")
	public Optional<StudentVO> getMarks(@PathVariable Integer id);
}
