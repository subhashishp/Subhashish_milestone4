package com.subhashish.VO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentVO {
	private Integer studentId;
	private Integer maths;
	private Integer physics;
	private Integer chemistry;
}
