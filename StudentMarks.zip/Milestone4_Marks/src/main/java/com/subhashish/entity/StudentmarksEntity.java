package com.subhashish.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class StudentmarksEntity {

	@Id
	private Integer studentId;
	private Integer maths;
	private Integer physics;
	private Integer chemistry;
}
