package com.subhashish.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.subhashish.entity.StudentmarksEntity;
import com.subhashish.repository.StudentMarksRepository;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("studentmarks")
public class StudentMarksController {

	@Autowired
	private StudentMarksRepository marksRepository;
	
	@GetMapping("/byid/{id}")
	public Optional<StudentmarksEntity> getMethodName(@PathVariable Integer id) {
		return marksRepository.findById(id);
	
	}
	
	@GetMapping
	public List<StudentmarksEntity> getAll() {
		return marksRepository.findAll();
	}
	
	
	@PostMapping("/add")
	public StudentmarksEntity postMethodName(@RequestBody StudentmarksEntity entity) {
		
		return marksRepository.save(entity);
	}
	
	
}
