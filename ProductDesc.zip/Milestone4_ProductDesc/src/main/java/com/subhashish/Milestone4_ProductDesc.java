package com.subhashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Milestone4_ProductDesc {

	public static void main(String[] args) {
		SpringApplication.run(Milestone4_ProductDesc.class, args);
	}

}
