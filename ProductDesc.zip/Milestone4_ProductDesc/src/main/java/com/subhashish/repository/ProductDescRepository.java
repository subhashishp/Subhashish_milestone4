package com.subhashish.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.subhashish.entity.ProductDescEntity;



@Repository
public interface ProductDescRepository extends JpaRepository<ProductDescEntity, Integer> {

}
