package com.subhashish.controller;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.subhashish.VO.ProductDescVO;



@FeignClient(url = "http://localhost:8889", value="ProductDesc")
public interface Consumer {
	
	@GetMapping("/productdesc/byid/{id}")
	public Optional<ProductDescVO> getProductDesc(@PathVariable Integer id);
}
